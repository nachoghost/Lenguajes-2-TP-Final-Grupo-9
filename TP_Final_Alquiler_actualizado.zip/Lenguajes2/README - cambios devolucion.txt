CAMBIOS EN LA DEVOLUCION DEL VEHICULO

1. VentanaDevolucion.java
   - Se agrego un selector para indicar si el vehiculo se devuelve "Sin daños" o "Con daños".
   - "Confirmar devolucion" pide confirmacion, registra el estado del vehiculo y finaliza el alquiler.
   - El boton se deshabilita luego de confirmar para evitar registrar dos veces la misma devolucion.
   - "Cerrar" cierra la ventana.

2. Alquiler.java
   - Se agrego finalizarAlquiler(String huboDaño).
   - El metodo verifica que el alquiler este ACTIVO y luego lo cambia a FINALIZADO.
   - Si no hay daños, la garantia se pone en 0 para registrar su liberacion.
   - Si hay daños, la garantia permanece registrada para una evaluacion posterior.

3. VentanaAlquiler.java
   - Al abrir la ventana de devolucion, se cierra la ventana anterior para que el boton "Cerrar" termine el flujo de la aplicacion.

IMPORTANTE
La garantia se modifica solamente dentro de los objetos del programa. No hay conexion con una entidad bancaria ni se ejecutan cobros, reintegros o desbloqueos reales de tarjetas.

Para abrir el proyecto, importar/abrir la carpeta Lenguajes2 en el entorno Java que utilizan.
