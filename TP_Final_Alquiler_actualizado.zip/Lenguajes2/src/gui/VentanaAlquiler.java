package gui;


import Clases_Importantes.Alquiler;
import Clases_Importantes.Cliente;
import Clases_Importantes.Sucursal;
import Clases_Importantes.Vehiculo;
import Logica.Logica;

import javax.swing.*;
import java.awt.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class VentanaAlquiler extends JFrame 
 {
	
	
        
	    private final Cliente cliente;
	    private final JComboBox<String> comboTipoVehiculo;
	    private final JComboBox<Integer> comboDuracion;
	    private Alquiler alquilerActual;

	    private JButton botonRegistrarRetiro;

	    private final JComboBox<Sucursal> comboRetiro;
	    private final JComboBox<Sucursal> comboDevolucion;

	    private final JSpinner fechaRetiro;
	    private final JTextField campoDevolucion; // Para poder calcular la fecha de devolucion automaticamente

	    public VentanaAlquiler(
	            Cliente cliente,
	            List<Sucursal> sucursales) {

	        super("Datos del alquiler");
	        
	        JButton botonConfirmar = new JButton("Confirmar elección");

	        botonRegistrarRetiro = new JButton("Registrar retiro");
	    

	        // Inicialmente no se puede registrar el retiro
	        botonRegistrarRetiro.setEnabled(false);

	        JPanel panelBotones = new JPanel(new FlowLayout());

	        panelBotones.add(botonConfirmar);
	        panelBotones.add(botonRegistrarRetiro);

	        botonConfirmar.addActionListener(e -> confirmarSeleccion());

	        botonRegistrarRetiro.addActionListener(e -> registrarRetiro());
	        

	       
	        this.cliente = cliente;
	        comboTipoVehiculo = new JComboBox<>(new String[] {
	        	    "Camioneta (Premium)",
	        	    "Automovil (Standard)",
	        	    "Motocicleta (Economico)"
	        	});

	        	comboDuracion = new JComboBox<>(
	        	    new Integer[] {7, 14, 21}
	        	);

	        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        setLayout(new BorderLayout(10, 10));

	        // Panel del formulario
	        JPanel formulario =
	                new JPanel(new GridLayout(0, 2, 10, 10));

	        formulario.setBorder(
	                BorderFactory.createEmptyBorder(15, 15, 15, 15)
	        );
	        formulario.add(new JLabel("Tipo de vehiculo:"));
	        formulario.add(comboTipoVehiculo);

	        formulario.add(new JLabel("Duracion (dias):"));
	        formulario.add(comboDuracion);
	        
	        add(formulario, BorderLayout.CENTER);
	        add(panelBotones, BorderLayout.SOUTH);

	        // Listas desplegables de sucursales
	        comboRetiro = new JComboBox<>();
	        comboDevolucion = new JComboBox<>();

	        for (Sucursal sucursal : sucursales) {
	            comboRetiro.addItem(sucursal);
	            comboDevolucion.addItem(sucursal);
	        }

	        // Selectores de fecha
	        fechaRetiro = new JSpinner(
	                new SpinnerDateModel(
	                        new Date(), null, null,
	                        Calendar.DAY_OF_MONTH
	                )
	        );


	        fechaRetiro.setEditor(
	                new JSpinner.DateEditor(fechaRetiro, "dd/MM/yyyy")
	        );

	        campoDevolucion = new JTextField(10);
			campoDevolucion.setEditable(false);

	        // Etiquetas y componentes
	        formulario.add(new JLabel("Sucursal de retiro:"));
	        formulario.add(comboRetiro);

	        formulario.add(new JLabel("Sucursal de devolución:"));
	        formulario.add(comboDevolucion);

	        formulario.add(new JLabel("Fecha de retiro:"));
	        formulario.add(fechaRetiro);

	        formulario.add(new JLabel("Fecha de devolución:"));
	        formulario.add(campoDevolucion);

	       
	        

			// Botón para volver a la pantalla de inicio de sesion
			JButton botonVolver = new JButton("Volver");
			panelBotones.add(botonVolver);
			botonVolver.addActionListener(e -> {
				dispose();
				new InicioSesion();
			});

	        // Agregar paneles a la ventana
	        add(formulario, BorderLayout.CENTER);
	        add(panelBotones, BorderLayout.SOUTH);
			
			fechaRetiro.addChangeListener(e -> calcularFechaDevolucion()); // Cada vez que cambie la fecha de retiro, calcular de nuevo la fecha de devolucion
			comboDuracion.addActionListener(e -> calcularFechaDevolucion()); // Cada vez que el usuario elija un pack de dias distnto, calcular de nuevo la fecha de devolucion
			calcularFechaDevolucion(); // Se ejecuta al abrir la ventana

	        pack();
	        setLocationRelativeTo(null);

			
			
	    }
		private void calcularFechaDevolucion() {
			LocalDate retiro = convertirFecha(fechaRetiro);
			int dias = (Integer) comboDuracion.getSelectedItem();
			campoDevolucion.setText(retiro.plusDays(dias).format(DateTimeFormatter.ofPattern("dd/MM/yyyy")));
		}
	    private void confirmarSeleccion() {
	    	    Sucursal retiro =
	    	            (Sucursal) comboRetiro.getSelectedItem();

	    	    Sucursal devolucion =
	    	            (Sucursal) comboDevolucion.getSelectedItem();

	    	    if (retiro == null || devolucion == null) {
	    	        JOptionPane.showMessageDialog(
	    	                this,
	    	                "Seleccione las sucursales."
	    	        );
	    	        return;
	    	    }

	    	    // Obtener las fechas
	    	    LocalDate inicio = convertirFecha(fechaRetiro);
	    	    

	    	    

	    	    // Obtener la duracion elegida
	    	    int duracion = (Integer) comboDuracion.getSelectedItem();

	    	    

	    	    // Comprobar que las fechas coincidan con la duracion
	    	    

	    	    // Obtener el tipo de vehiculo elegido
	    	    String tipoSeleccionado =
	    	            (String) comboTipoVehiculo.getSelectedItem();

	    	    Vehiculo vehiculo =
	    	            crearVehiculoSeleccionado(tipoSeleccionado);

	    	    // Crear el alquiler
	    	    alquilerActual = new Alquiler(
	    	    	    duracion,
	    	    	    cliente,
	    	    	    vehiculo,
	    	    	    "Pendiente",
	    	    	    retiro,
	    	    	    devolucion
	    	    	);
	    	    // Calcular el precio mediante la clase Logica
	    	    Logica logica = new Logica();

	    	    int precio = logica.calcularPrecio(alquilerActual, vehiculo);

	    	    // Guardar los importes en el objeto Alquiler
	    	    alquilerActual.setPrecio(precio);
	    	    int garantia = vehiculo.getMontoGarantia();
	    	    
	    	    botonRegistrarRetiro.setEnabled(true);

	    	    // Mostrar el resultado
	    	    JOptionPane.showMessageDialog(
	    	            this,
	    	            "Resumen del alquiler:"
	    	            	    + "\n\nVehiculo: " + vehiculo.getTipo()
	    	            	    + "\nDuracion: " + duracion + " dias"
	    	            	    + "\nTarifa diaria: $" + vehiculo.getTarifaDiaria()
	    	            	    + "\nPrecio del alquiler: $" + precio
	    	            	    + "\nGarantia a bloquear al retirar: $" + garantia
	    	            	    + "\n\nEstado: " + alquilerActual.getEstado()
	    	    );
	    	
	    }

	    private LocalDate convertirFecha(JSpinner selector) {

	        Date fecha = (Date) selector.getValue();

	        return fecha.toInstant()
	                .atZone(ZoneId.systemDefault())
	                .toLocalDate();
	    }
	    private Vehiculo crearVehiculoSeleccionado(String tipo) {

	        switch (tipo) {

	            case "Camioneta (Premium)":
	                return new Vehiculo(
	                    "Camioneta", "Toyota", "Hilux", "RPD-209",2019,
	                    4, 80, 1000, 4000
	                );

	            case "Automovil (Standard)":
	                return new Vehiculo(
	                    "Automovil", "Chevrolet", "Celta", "MNY-189",2009,
	                    4, 60, 500, 2000
	                );

	            case "Motocicleta (Economico)":
	                return new Vehiculo(
	                    "Motocicleta", "Pendiente", "Pendiente", "GER-206",1999,
	                    1, 40, 300, 1500
	                );

	            default:
	                throw new IllegalArgumentException(
	                    "Tipo de vehiculo no valido"
	                );
	        }
	    }
	    private void registrarRetiro() {

	        if (alquilerActual == null) {
	            JOptionPane.showMessageDialog(
	                this,
	                "Primero debe confirmar la eleccion del vehiculo."
	            );
	            return;
	        }

	        try {

	            // Activar el alquiler y registrar la garantia
	            alquilerActual.activarAlquiler();

	            JOptionPane.showMessageDialog(
	                this,
	                "Retiro registrado correctamente."
	                + "\n\nGarantia registrada: $"
	                + alquilerActual.getGarantia()
	                + "\nEstado del alquiler: "
	                + alquilerActual.getEstado()
	            );

	            // Evitar activar nuevamente el mismo alquiler
	            botonRegistrarRetiro.setEnabled(false);
				new VentanaDevolucion(alquilerActual).setVisible(true);
                dispose(); // El alquiler ya fue retirado; se continúa en la ventana de devolución.
	        } catch (IllegalStateException ex) {

	            JOptionPane.showMessageDialog(
	                this,
	                ex.getMessage()
	            );
	        }
	    }

	}


