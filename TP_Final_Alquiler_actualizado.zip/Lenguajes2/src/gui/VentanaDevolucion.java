package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Clases_Importantes.Alquiler;

public class VentanaDevolucion extends JFrame {

    private final Alquiler alquiler;
    private final JComboBox<String> comboEstadoVehiculo;
    private final JLabel etiquetaGarantia;
    private final JButton botonConfirmar;

    public VentanaDevolucion(Alquiler alquiler) {
        super("Ventana de Devolución");

        this.alquiler = alquiler;

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        setSize(550, 320);
        setLocationRelativeTo(null);

        // Etiquetas con los datos del alquiler.
        JLabel etiquetaCliente = new JLabel(
                "Cliente: " + alquiler.getCliente().getNombre() + " "
                        + alquiler.getCliente().getApellido());

        JLabel etiquetaVehiculo = new JLabel(
                "Vehículo: " + alquiler.getVehiculo().getMarca() + " "
                        + alquiler.getVehiculo().getModelo() + " "
                        + alquiler.getVehiculo().getAño());

        JLabel etiquetaPatenteVehiculo = new JLabel(
                "Patente: " + alquiler.getVehiculo().getPatente());

        JLabel etiquetaSucursalDevolucion = new JLabel(
                "Sucursal de devolución: " + alquiler.getSucursalDevolucion());

        JLabel etiquetaPrecioAlquiler = new JLabel(
                "Precio del alquiler: $" + alquiler.getPrecio());

        etiquetaGarantia = new JLabel(
                "Valor de la garantía: $" + alquiler.getGarantia());

        // El usuario indica en qué estado se recibe el vehículo.
        comboEstadoVehiculo = new JComboBox<>(
                new String[] { "Sin daños", "Con daños" });

        JPanel panelEstadoVehiculo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelEstadoVehiculo.add(new JLabel("Estado del vehículo:"));
        panelEstadoVehiculo.add(comboEstadoVehiculo);

        // Panel con la información del alquiler.
        JPanel panelEtiquetas = new JPanel(new GridLayout(0, 1, 10, 5));
        panelEtiquetas.setBorder(
                BorderFactory.createEmptyBorder(15, 15, 15, 15));
        panelEtiquetas.add(etiquetaCliente);
        panelEtiquetas.add(etiquetaVehiculo);
        panelEtiquetas.add(etiquetaPatenteVehiculo);
        panelEtiquetas.add(etiquetaSucursalDevolucion);
        panelEtiquetas.add(etiquetaPrecioAlquiler);
        panelEtiquetas.add(etiquetaGarantia);
        panelEtiquetas.add(panelEstadoVehiculo);

        // Botones.
        botonConfirmar = new JButton("Confirmar devolución");
        JButton botonCerrar = new JButton("Cerrar");

        JPanel panelBotones = new JPanel(new FlowLayout());
        panelBotones.add(botonConfirmar);
        panelBotones.add(botonCerrar);

        // Acciones de los botones.
        botonConfirmar.addActionListener(e -> confirmarDevolucion());
        botonCerrar.addActionListener(e -> dispose());

        add(panelEtiquetas, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    private void confirmarDevolucion() {

        // Evita registrar una devolución si el alquiler no está activo.
        if (alquiler.getEstado() != Alquiler.Estado.ACTIVO) {
            JOptionPane.showMessageDialog(
                    this,
                    "El alquiler no se encuentra activo.",
                    "No se puede confirmar",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        String estadoVehiculo = (String) comboEstadoVehiculo.getSelectedItem();
        String huboDaño = "Con daños".equals(estadoVehiculo) ? "Sí" : "No";

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Confirma la devolución del vehículo?\n"
                        + "Estado informado: " + estadoVehiculo,
                "Confirmar devolución",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        int garantiaAntesDeDevolver = alquiler.getGarantia();

        try {
            // Registra los daños, cambia el estado a FINALIZADO y,
            // si no hay daños, registra la liberación de la garantía.
            alquiler.finalizarAlquiler(huboDaño);

            etiquetaGarantia.setText(
                    "Valor de la garantía: $" + alquiler.getGarantia());

            String mensaje = "Devolución registrada correctamente."
                    + "\n\nEstado del vehículo: " + estadoVehiculo
                    + "\nEstado del alquiler: " + alquiler.getEstado();

            if ("No".equals(huboDaño)) {
                mensaje += "\n\nLa garantía de $" + garantiaAntesDeDevolver
                        + " se registró como liberada.";
            } else {
                mensaje += "\n\nLa garantía de $" + garantiaAntesDeDevolver
                        + " permanece retenida para evaluar los daños.";
            }

            JOptionPane.showMessageDialog(
                    this,
                    mensaje,
                    "Devolución confirmada",
                    JOptionPane.INFORMATION_MESSAGE);

            // Impide confirmar dos veces la misma devolución.
            botonConfirmar.setEnabled(false);
            comboEstadoVehiculo.setEnabled(false);

        } catch (IllegalStateException | IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage(),
                    "Error al registrar la devolución",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
