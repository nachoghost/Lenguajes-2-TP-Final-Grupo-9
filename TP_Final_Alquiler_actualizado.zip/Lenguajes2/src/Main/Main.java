package Main;

import Clases_Importantes.Alquiler;
import Clases_Importantes.Cliente;
import Clases_Importantes.Sucursal;
import Clases_Importantes.Vehiculo;
import java.util.ArrayList;
import gui.InicioSesion;
import gui.VentanaDevolucion;

public class Main {
    public static void main(String[] args) throws Exception {
        
        
        Sucursal Sucursal_1 = new Sucursal("Sucursal Salta Capital", "Salta", "Salta Capital", "Larraboure 1171");
        Sucursal Sucursal_2 = new Sucursal("Sucursal Jujuy", "Jujuy", "San Salvador de Jujuy", "Independencia 1478");
        
        
        ArrayList<Sucursal> Sucursales = new ArrayList<Sucursal>();
        Sucursales.add(Sucursal_1);
        Sucursales.add(Sucursal_2);

        //System.out.println(Cliente.clienteLogin());
        InicioSesion test = new InicioSesion();
        //new VentanaDevolucion(Alquiler alquiler).setVisible(true);
    }
}
