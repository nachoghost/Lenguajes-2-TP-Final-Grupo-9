package gui;


import Clases_Importantes.Cliente;
import Clases_Importantes.Sucursal;

import javax.swing.*;
import java.awt.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;

public class VentanaAlquiler extends JFrame 
 {
	

	    private final Cliente cliente;

	    private final JComboBox<Sucursal> comboRetiro;
	    private final JComboBox<Sucursal> comboDevolucion;

	    private final JSpinner fechaRetiro;
	    private final JSpinner fechaDevolucion;

	    public VentanaAlquiler(
	            Cliente cliente,
	            List<Sucursal> sucursales) {

	        super("Datos del alquiler");

	        this.cliente = cliente;

	        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        setLayout(new BorderLayout(10, 10));

	        // Panel del formulario
	        JPanel formulario =
	                new JPanel(new GridLayout(0, 2, 10, 10));

	        formulario.setBorder(
	                BorderFactory.createEmptyBorder(15, 15, 15, 15)
	        );

	        // Listas desplegables de sucursales
	        comboRetiro = new JComboBox<>();
	        comboDevolucion = new JComboBox<>();

	        for (Sucursal sucursal : sucursales) {
	            comboRetiro.addItem(sucursal);
	            comboDevolucion.addItem(sucursal);
	        }

	        // Selectores de fecha
	        fechaRetiro = new JSpinner(
	                new SpinnerDateModel(
	                        new Date(), null, null,
	                        Calendar.DAY_OF_MONTH
	                )
	        );

	        fechaDevolucion = new JSpinner(
	                new SpinnerDateModel(
	                        new Date(), null, null,
	                        Calendar.DAY_OF_MONTH
	                )
	        );

	        fechaRetiro.setEditor(
	                new JSpinner.DateEditor(fechaRetiro, "dd/MM/yyyy")
	        );

	        fechaDevolucion.setEditor(
	                new JSpinner.DateEditor(fechaDevolucion, "dd/MM/yyyy")
	        );

	        // Etiquetas y componentes
	        formulario.add(new JLabel("Sucursal de retiro:"));
	        formulario.add(comboRetiro);

	        formulario.add(new JLabel("Sucursal de devolución:"));
	        formulario.add(comboDevolucion);

	        formulario.add(new JLabel("Fecha de retiro:"));
	        formulario.add(fechaRetiro);

	        formulario.add(new JLabel("Fecha de devolución:"));
	        formulario.add(fechaDevolucion);

	        // Botón para confirmar la selección
	        JButton botonConfirmar = new JButton("Confirmar");

	        JPanel panelBoton = new JPanel(new FlowLayout());
	        panelBoton.add(botonConfirmar);

	        botonConfirmar.addActionListener(
	                e -> confirmarSeleccion()
	        );

	        // Agregar paneles a la ventana
	        add(formulario, BorderLayout.CENTER);
	        add(panelBoton, BorderLayout.SOUTH);

	        pack();
	        setLocationRelativeTo(null);
	    }

	    private void confirmarSeleccion() {

	        Sucursal retiro =
	                (Sucursal) comboRetiro.getSelectedItem();

	        Sucursal devolucion =
	                (Sucursal) comboDevolucion.getSelectedItem();

	        if (retiro == null || devolucion == null) {
	            JOptionPane.showMessageDialog(
	                    this,
	                    "No hay sucursales disponibles."
	            );
	            return;
	        }

	        LocalDate inicio = convertirFecha(fechaRetiro);
	        LocalDate fin = convertirFecha(fechaDevolucion);

	        if (!fin.isAfter(inicio)) {
	            JOptionPane.showMessageDialog(
	                    this,
	                    "La fecha de devolución debe ser posterior "
	                            + "a la fecha de retiro."
	            );
	            return;
	        }

	        long dias = ChronoUnit.DAYS.between(inicio, fin);

	        JOptionPane.showMessageDialog(
	                this,
	                "Cliente: " + cliente.getNombre()
	                        + " " + cliente.getApellido()
	                        + "\nSucursal de retiro: " + retiro
	                        + "\nSucursal de devolución: " + devolucion
	                        + "\nFecha de retiro: " + inicio
	                        + "\nFecha de devolución: " + fin
	                        + "\nDuración: " + dias + " días"
	        );
	    }

	    private LocalDate convertirFecha(JSpinner selector) {

	        Date fecha = (Date) selector.getValue();

	        return fecha.toInstant()
	                .atZone(ZoneId.systemDefault())
	                .toLocalDate();
	    }
	}


