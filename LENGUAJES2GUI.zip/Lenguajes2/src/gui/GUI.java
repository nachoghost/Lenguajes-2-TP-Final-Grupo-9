package gui;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JOptionPane;
import Clases_Importantes.Cliente;
import Clases_Importantes.Sucursal;

import java.util.Arrays;
import java.util.List;

public class GUI {
	
    public GUI()  {
    	JFrame ventana = new JFrame("Pantalla de Inicio de Sesion");
    	ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    	// Panel principal
    	JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));

    	// Panel que contiene las etiquetas y los campos
    	JPanel formulario = new JPanel(new GridLayout(0, 2, 10, 10));

    	// Nombre
    	JLabel etiquetaNombre = new JLabel("Ingrese su nombre:");
    	JTextField campoNombre = new JTextField(20);

    	formulario.add(etiquetaNombre);
    	formulario.add(campoNombre);

    	// Apellido
    	JLabel etiquetaApellido = new JLabel("Ingrese su apellido:");
    	JTextField campoApellido = new JTextField(20);

    	formulario.add(etiquetaApellido);
    	formulario.add(campoApellido);

    	// DNI
    	JLabel etiquetaDNI = new JLabel("Ingrese su DNI:");
    	JTextField campoDNI = new JTextField(20);

    	formulario.add(etiquetaDNI);
    	formulario.add(campoDNI);
    	

    	// Direccion
    	JLabel etiquetaDireccion = new JLabel("Ingrese su direccion:");
    	JTextField campoDireccion = new JTextField(20);

    	formulario.add(etiquetaDireccion);
    	formulario.add(campoDireccion);

    	// Tarjeta
    	JLabel etiquetaTarjeta =
    	    new JLabel("Numero de tarjeta de credito:");
    	JTextField campoTarjeta = new JTextField(20);

    	formulario.add(etiquetaTarjeta);
    	formulario.add(campoTarjeta);

    	// Boton
    	JButton boton = new JButton("Continuar");

    	JPanel panelBoton = new JPanel(new FlowLayout());
    	panelBoton.add(boton);
    	
    	boton.addActionListener(e -> {

    	    String nombre = campoNombre.getText().trim();
    	    String apellido = campoApellido.getText().trim();
    	    String dniTexto = campoDNI.getText().trim();
    	    String direccion = campoDireccion.getText().trim();
    	    String tarjeta = campoTarjeta.getText().trim();

    	    // Comprobar que los campos estén completos
    	    if (nombre.isEmpty() || apellido.isEmpty()
    	            || dniTexto.isEmpty()
    	            || direccion.isEmpty() || tarjeta.isEmpty()) {

    	        JOptionPane.showMessageDialog(
    	                ventana,
    	                "Complete todos los campos."
    	        );
    	        return;
    	    }

    	    try {
    	        // Convertir el DNI a entero
    	        int dni = Integer.parseInt(dniTexto);

    	        // Crear el objeto Cliente
    	        Cliente cliente = new Cliente(
    	                nombre,
    	                apellido,
    	                dni,
    	                direccion,
    	                tarjeta
    	        );

    	        // Sucursales de ejemplo: reemplazar por las reales
    	        List<Sucursal> sucursales = Arrays.asList(
    	                new Sucursal(
    	                        "Sucursal Centro",
    	                        "Salta",
    	                        "Salta",
    	                        "Dirección ficticia 1"
    	                ),
    	                new Sucursal(
    	                        "Sucursal Norte",
    	                        "Salta",
    	                        "Salta",
    	                        "Dirección ficticia 2"
    	                )
    	        );

    	        // Abrir la segunda ventana
    	        VentanaAlquiler nuevaVentana =
    	                new VentanaAlquiler(cliente, sucursales);

    	        nuevaVentana.setVisible(true);

    	        // Cerrar la primera ventana
    	        ventana.dispose();

    	    } catch (NumberFormatException ex) {

    	        JOptionPane.showMessageDialog(
    	                ventana,
    	                "El DNI debe contener un número válido."
    	        );
    	    }
    	});

    	// Organizar los paneles
    	panelPrincipal.add(formulario, BorderLayout.CENTER);
    	panelPrincipal.add(panelBoton, BorderLayout.SOUTH);

    	ventana.setContentPane(panelPrincipal);
    	ventana.pack();
    	ventana.setLocationRelativeTo(null);
    	ventana.setVisible(true);
    	
    	
    	//Ventana sucursal
    	
    	boton.addActionListener(e->{
    		
    	});
    	
        /*// Operaciones con el cuadro de la ventana
        JFrame ventana = new JFrame("Pantalla de Inicio de Sesion");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(400, 400);
        ventana.setLayout(new FlowLayout());
        

        //Panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        

        // Etiquetas
        JLabel etiquetaNombre = new JLabel("Ingrese su nombre: ");
        panel.add(etiquetaNombre);
        ventana.add(etiquetaNombre);

        etiquetaNombre.setLayout(new FlowLayout());
        JLabel etiquetaApellido = new JLabel("Ingrese su apellido: ");
        panel.add(etiquetaApellido);
        ventana.add(etiquetaApellido);

        JLabel etiquetaDNI = new JLabel("Ingrese su DNI: ");
        panel.add(etiquetaDNI);
        ventana.add(etiquetaDNI);

        JLabel etiquetaDireccion = new JLabel("Ingrese su direccion: ");
        panel.add(etiquetaDireccion);
        ventana.add(etiquetaDireccion);

        JLabel etiquetaNroTarjetaCredito = new JLabel("Ingrese su numero de tarjeta de credito");
        panel.add(etiquetaNroTarjetaCredito);
        ventana.add(etiquetaNroTarjetaCredito);
        


        // Campos de texto
        JTextField campoNombre = new JTextField(20);
        ventana.add(campoNombre);
        campoNombre.setLayout(new FlowLayout());

        JTextField campoApellido = new JTextField(20);
        ventana.add(campoApellido);
        campoApellido.setLayout(new FlowLayout());
        
        
        
        JTextField campoDNI = new JTextField(20);
        ventana.add(campoDNI);
        campoDNI.setLayout(new FlowLayout());
        JTextField campoDireccion = new JTextField(20);
        ventana.add(campoDireccion);
        campoDireccion.setLayout(new FlowLayout());
        JTextField campoTarjeta = new JTextField(20);
        ventana.add(campoTarjeta);
        campoTarjeta.setLayout(new FlowLayout());

        // Boton
        JButton boton = new JButton("Apretame!!!");
        panel.setLayout(new FlowLayout());
        ventana.add(boton);
        
        // Final
        ventana.setVisible(true);*/
	
    }
}
