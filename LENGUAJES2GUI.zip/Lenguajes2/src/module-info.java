module Lenguajes2 {

    requires java.desktop;
}