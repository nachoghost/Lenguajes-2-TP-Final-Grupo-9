
package Clases_Importantes;
import java.util.Scanner;
import java.util.InputMismatchException;
public class Cliente {
    private String nombre;
    private String apellido;
    private int DNI;
    private String direccion;
    private String nroTarjetaCredito; //El sistema solo acepta tarjeta de credito!
    
    // Constructor

    public Cliente(String nombre, String apellido, int DNI, String direccion, String nroTarjetaCredito2) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.direccion = direccion;
        this.DNI = DNI;
        this.nroTarjetaCredito = nroTarjetaCredito2;
    }

    // Getters y Setters

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getApellido() {
        return apellido;
    }
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    public int getDNI() {
        return DNI;
    }
    public void setDNI(int DNI) {
        this.DNI = DNI;
    }
    public String getDireccion() {
        return direccion;
    }
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    public String getNroTarjetaCredito() {
        return nroTarjetaCredito;
    }
    public void setNroTarjetaCredito(String nroTarjetaCredito) {
        this.nroTarjetaCredito = nroTarjetaCredito;
    }
    @Override 
    public String toString() {
        return ("Nombre: " + nombre + "\n" + "Apellido: " +  apellido + "\n" + "DNI: " + DNI + "\n" + "Direccion: " + direccion + "\n" + "Numero de tarjeta de credito: " + nroTarjetaCredito);
    }



    // Metodos
    // Metodo de login de cliente
    public static Cliente clienteLogin() {
        try (Scanner Scanner = new Scanner(System.in)) {
            System.out.println("Ingrese su nombre: ");
            String nombre = Scanner.nextLine();

            System.out.println("Ingrese su apellido: ");
            String apellido = Scanner.nextLine();

            System.out.println("Ingrese su DNI: ");
            int DNI = Integer.parseInt(Scanner.nextLine());

            System.out.println("Ingrese su direccion: ");
            String direccion = Scanner.nextLine();

            System.out.println("Ingrese su numero de tarjeta de credito: ");
            String nroTarjetaCredito = Scanner.nextLine();

            return new Cliente(nombre, apellido, DNI, direccion, nroTarjetaCredito);
        } 
        }
    // Metodo de Cliente para seleccionar sucursal de retiro y devolucion de vehiculo.
   /* boolean running = true;
    public String seleccionSucursal() {
        while (running) {
            System.out.println("===== Menu Principal =====");
            System.out.println("1. Sucursal Salta Capital");
            System.out.println("2. Sucursal Jujuy");
            System.out.println("3. Sucursal Tucuman");
            
        }*/
        

    }
    
    
    

